$SPARK_HOME/bin/spark-submit --master yarn --jars ~/lib/elasticsearch-spark-20_2.11-6.3.0.jar ~/script/Beijing.py
